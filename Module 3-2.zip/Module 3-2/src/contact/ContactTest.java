package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactTest {
	Contact contact = new Contact("1", "Jennifer", "Kim", "123456789", "123 Street 55555");

	@Test
	void getContactID() {
		assertEquals("1", contact.getContactID());
	}
	
	@Test
	void getFirstName() {
		assertEquals("firstName", contact.getFirstName());
	}
	
	@Test
	void getLastName() {
		assertEquals("lastName", contact.getLastName());
	}
	
	@Test
	void getnumber() {
		assertEquals("number", contact.getnumber());
	}
	
	@Test
	void getAddress() {
		assertEquals("address", contact.getAddress());
	}

}
