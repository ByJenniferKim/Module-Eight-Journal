package contact;

public class Contact {
	String contactID;
	String firstName;
	String lastName;
	String number;
	String address;
	
	public Contact (String contactID, String firstName, String lastName, String number, String address) {
		super();
		
		this.contactID = contactID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.number = number;
		this.address = address;
	}
	public String getContactID() {
		return contactID;
	}
	public void setContactID (String contactID) {
		this.contactID = contactID;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName (String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName (String lastName) {
		this.lastName = lastName;
	}
	public String getnumber() {
		return number;
	}
	public void setPhoneNumber (String phoneNumber) {
		this.number = phoneNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress (String address) {
		this.address = address;
	}
	@Override
	
	public String toString() {
		
		return "Contact [contactID=" + contactID + ", firstName=" + firstName + ", lastName=" + lastName + ", Number=" + number + ", Address=" + address + "]";
	}
}
