package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactServiceTest {

	@Test
	void testAdd() {
		ContactService cs = new ContactService();
		
		Contact t1 = new Contact("01", "Bobby", "Brown", "123", "ABC St");
		assertEquals(true, cs.addContact(t1));
	}
	
	@Test
	public void testDelete() {
		ContactService cs = new ContactService();
		Contact t1 = new Contact("01", "Bobby", "Brown", "123", "ABC St");
		Contact t2 = new Contact("02", "Billy", "Bob", "234", "BCD St");
		Contact t3 = new Contact("03", "Sally", "Sam", "345", "CDF St");
		
		cs.addContact(t1);
		cs.addContact(t2);
		cs.addContact(t3);
		assertEquals(true, cs.deleteContact("02"));
		assertEquals(false, cs.deleteContact("00"));
		assertEquals(false, cs.deleteContact("02"));
	}
}
