package contact;
import java.util.ArrayList;

public class ContactService {
	private ArrayList contacts;
	
	public ContactService() {
		contacts = new ArrayList<>();
	}
	public boolean addContact(Contact contact) {
		boolean isPresent = false;
		for (Contact contactList:contacts) {
			if (contactList.equals(contact)) {
				isPresent = true;
			}
		}
		if (!isPresent) {
			contacts.add(contact);
			
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean deleteContact(String contactID) {
		for (Contact contactList:contacts) {
			if (contactList.getContactID().equals(contactID)) {
				contacts.remove(contactList);
				return true;
			}
		}
		return false;
	}
	
	public boolean updateContact(String contactID, String firstName, String lastName, String nummber, String address) {
		for (Contact contactList:contacts) {
			if (contactList.getContactID().equals(contactID)) {
				if (!firstName.equals("") && !(firstName.length() > 10)) {
					contactList.setFirstName(firstName);
				}
				if (!lastName.equals("") && !(lastName.length() > 10)) {
					contactList.setFirstName(lastName);
				}
				if (!number.equals("") && (number.length() == 10)) {
					contactList.setFirstName(number);
				}
				if (!address.equals("") && !(address.length() > 30)) {
					contactList.setFirstName(address);
				}
				return true;
				}
			}
		return false;
		}
	}